declare module '*.module.css' {
  const content: any;
  export = content;
}
declare module '*.module.scss' {
  const content: any;
  export = content;
}
declare module '*.module.less' {
  const content: any;
  export = content;
}
declare module '*.ts' {
  const content: any = {

  };
  export = content; 
}
declare module '*.js' {
  const content: any;
  export = content; 
}
declare module '*.module.css' {
  const content: any;
  export = content;
}
declare module '*.module.scss' {
  const content: any;
  export = content;
}
declare module '*.module.less' {
  const content: any;
  export = content;
}

declare module '*.css' {
  const content: any;
  export = content;
}
declare module '*.scss' {
  const content: any;
  export = content;
}
declare module '*.less' {
  const content: any;
  export = content;
}
declare module '*.jpg';
declare module '*.png';
declare module '*.gif';