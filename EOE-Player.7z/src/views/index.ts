
import Ranking from './Ranking';
import Player from './Player';
import Recommend from './Recommend';
import Search from './Search';
import Login from './Login';
export {
  Ranking,
  Player,
  Recommend,
  Search,
  Login,
}